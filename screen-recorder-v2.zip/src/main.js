const {app, BrowserWindow} = require('electron')
const path = require('path')
let mainWindow


console.log(app.getAppPath())
app.on('ready', () => {
  mainWindow = new BrowserWindow({
    height: 720,
    width: 365,
    webPreferences: {
      devTools: true
    },
    maximizable: false,
    icon: path.join(__dirname, 'assets/icons/icon.png')

    
  //  ,frame: false
  });

 
  mainWindow.loadURL('file://' + __dirname + '/index.html')
  // mainWindow.webContents.openDevTools({mode:'undocked'})
  
});



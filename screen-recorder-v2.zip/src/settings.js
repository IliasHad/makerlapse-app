const { remote} = require("electron");

const app = remote.app;
const userAppPath =  app.getPath('userData');
const path = require('path')
const fs = require('fs')
document.addEventListener("DOMContentLoaded", () => {

let typeInput 
  
  document.querySelector(".timelapse__container select").addEventListener("change", e => {
        console.log(e.target.value);

        typeInput = e.target.value
        if(e.target.value.includes('photo')) {
            document.querySelector(".input__fields").style.display = "block"
        }
        else {
            document.querySelector(".input__fields").style.display = "none"

        }

      })

      document.querySelector(".settings__form").addEventListener("submit", (e) => {
e.preventDefault()

imagePerSecond =  e.target[0].value
console.log(imagePerSecond)

let data = {
    typeOfInput:typeInput,
    imagePerSecond
}

fs.writeFile(path.join(userAppPath, "settings.json"), JSON.stringify(data), function(err){
    if(err) console.log(err)
    else console.log('File Cretaed')
})
    })

})
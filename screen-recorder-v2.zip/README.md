# Screen Recorder

Electron-based screen recorder application.

![screenshot](ss.png)
You can choose a specific screen/window to record, and the record file is saved
as `webm`.

## Install

```sh
git clone https://github.com/davchezt/screen-recorder.git

cd screen-recorder

yarn

yarn start
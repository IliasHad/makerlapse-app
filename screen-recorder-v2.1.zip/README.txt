Hey,


How Makerlapse works: 

You have two options to make a timelapse video


Make a timelapse from screen recorded video (Default)

You can choose which screen or application you want to record and after that press record button and it's will start recording the video 

When you want to stop the recording just click on record button and after that choose which format you want to get for the timelapse video , choose the timelapse video

duration  and click on download timelapse video and it's will start processing the video after you the processing is done you can click on open timelapse video to watch the video




Make a timelapse from screenshots

To generate timelapse video from screenshots , you can go to settings page and select timelapse video from photo and choose how many seocndes betwen each screenshots

for example 2s between screenshots and save your new settings and go to the home page and press the record button and it's will generate screenshots each second requested

When you want to stop the recording just click on record button and after that choose which format you want to get for the timelapse video , choose the timelapse video

duration and after that click on download timelapse video and it's will start processing the video after you the processing is done you can click on open timelapse video to watch the video




Taking Photo:

You can 


Would love to hear your feedback and if everthing is working . Feel free to contact me at makerlapse@gmail.com


Thank you so much,
Ilias Haddad